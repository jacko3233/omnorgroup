<?php get_header(); ?>
<section class="hero relative h-screen overflow-hidden bg-black">
  <canvas id="waveCanvas" class="absolute inset-0"></canvas>
  <div class="relative z-10 flex flex-col items-center justify-center h-full text-center px-4">
    <h1 class="text-white text-4xl md:text-6xl font-bold">
      Built from the North.<br /> Delivered Worldwide.
    </h1>
  </div>
</section>
<section class="services py-16 bg-gray-900 text-white">
  <div class="container mx-auto grid gap-8 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
    <?php
    $services = new WP_Query(['post_type'=>'service','posts_per_page'=>4]);
    while($services->have_posts()): $services->the_post(); ?>
      <div class="service-card p-6 bg-gray-800 rounded-lg text-center">
        <?php the_post_thumbnail('medium', ['class'=>'mx-auto mb-4']); ?>
        <h3 class="text-xl font-semibold mb-2"><?php the_title(); ?></h3>
        <p><?php the_excerpt(); ?></p>
      </div>
    <?php endwhile; wp_reset_postdata(); ?>
  </div>
</section>
<?php get_footer(); ?>