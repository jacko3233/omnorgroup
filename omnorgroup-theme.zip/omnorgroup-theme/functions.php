<?php
define('THEME_DIR', get_stylesheet_directory_uri());
function omnorgroup_enqueue() {
  wp_enqueue_script('threejs', 'https://unpkg.com/three@0.152.0/build/three.min.js', [], null, true);
  wp_enqueue_script('gltfloader', 'https://unpkg.com/three@0.152.0/examples/js/loaders/GLTFLoader.js', ['threejs'], null, true);
  wp_enqueue_script('hero-js', THEME_DIR . '/assets/js/hero.js', [], null, true);
}
add_action('wp_enqueue_scripts', 'omnorgroup_enqueue');
?>