import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';

const canvas = document.getElementById('waveCanvas');
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(35, window.innerWidth/window.innerHeight, 0.1, 1000);
camera.position.set(0, 10, 25);

const renderer = new THREE.WebGLRenderer({ canvas, alpha: true });
renderer.setSize(window.innerWidth, window.innerHeight);

const geo = new THREE.PlaneGeometry(40, 40, 80, 80);
const mat = new THREE.MeshBasicMaterial({ wireframe: true, transparent: true, opacity: 0.6, color: 0x0077ff });
const wave = new THREE.Mesh(geo, mat);
wave.rotation.x = -Math.PI / 2;
scene.add(wave);

const loader = new GLTFLoader();
loader.load('/wp-content/themes/omnorgroup-theme/assets/models/vessel.glb', (gltf) => {
  const vessel = gltf.scene;
  vessel.scale.set(0.5, 0.5, 0.5);
  vessel.position.set(0, 1.5, 0);
  scene.add(vessel);
});

let time = 0;
function animate() {
  requestAnimationFrame(animate);
  time += 0.01;
  const pos = wave.geometry.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const y = Math.sin((i + time * 5) * 0.1) * 0.3;
    pos.setY(i, y);
  }
  pos.needsUpdate = true;
  renderer.render(scene, camera);
}
animate();

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
